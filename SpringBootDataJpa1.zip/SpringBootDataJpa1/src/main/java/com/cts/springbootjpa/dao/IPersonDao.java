package com.cts.springbootjpa.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.Person;
@Repository
public interface IPersonDao  extends JpaRepository<Person, Integer> {

	@Query(value="FROM Person p where p.personName =:pn")
	public Person findByPersonName(@Param("pn") String name);
	
	@Query(value="FROM Person p where p.personName =:pn and p.addr=:addr")
	public Person findUsingNameAddr(@Param("pn")String n, @Param("addr") String ad);
	/*@Modifying
	@Query(value="UPDATE Person p SET p.personName=:pn and p.addr=:addr where p.personId=pid")
	public int updateperson(Person person, int id);*/
	//public Person updateById(int id, String name, String addr);
	/*@Query(value="UPDATE Person p SET p.personName=:pn and p.addr=:addr where p.personId=pid")
	public int updatePerson(Person person, int pid);*/

	
	
}
