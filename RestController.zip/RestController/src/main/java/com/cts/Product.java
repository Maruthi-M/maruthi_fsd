package com.cts;

public class Product {
private int productid;
private String productname;
private int productquantity;
public Product(int i, String string, int j) {
	this.productid=i;
	this.productname=string;
	this.productquantity=j;
}
public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}
public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}
public int getProductquantity() {
	return productquantity;
}
public void setProductquantity(int productquantity) {
	this.productquantity = productquantity;
}




}
