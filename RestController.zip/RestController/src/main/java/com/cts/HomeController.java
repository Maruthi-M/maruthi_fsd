package com.cts;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	List<Product> liobj=new ArrayList();
	Map<Integer,Product> mapobj=new HashMap();
	public HomeController()
	{
		liobj.add(new Product(100,"tv",2));
		liobj.add(new Product(102,"dvd",8));
		liobj.add(new Product(104,"remote",2));
		liobj.add(new Product(103,"phone",5));
		
		 mapobj.put(100,new Product(100,"smartphone",3));
		  mapobj.put(102,new Product(189,"watches",3));
		  mapobj.put(1011,new Product(178,"smartwatch",3));
		  mapobj.put(123,new Product(167,"keypadmobiles",3));
		 
		
	}
	
	
@RequestMapping("/data")
public String getm1() {
	return "data";
}
@RequestMapping("/jsonlistdata")
public List getProduct()
{
	return liobj;
}
@RequestMapping("/jsonmapdata")
public Map getmappro()
{
	return mapobj;
}
	
	
}
