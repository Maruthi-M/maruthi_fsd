package com.cts.SpringBoot.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;
import com.cts.SpringBoot.dao.ProjectDao;
import com.cts.SpringBoot.dao.ShoppingCartDao;
@Service
public class ShoppingCartService {
@Autowired 
public ShoppingCartDao cartdao;
@Autowired
public ProjectDao buyerdao;
//delete cart item
public String deleteCartItem(int id) 
{
	 cartdao.deleteById(id);
	 return "/cart item deleted/";
}

//add cart item

/*
public Optional<Object> addingCartItem(int bid, int id) {
	
	return buyerdao.findById(bid).map(buyer -> {
   
        return cartdao.saveAll(id);
    });
}*/
/*public Optional<ShoppingCart> addCartItem(ShoppingCart cartItem, Integer buyerId) {
	return buyerdao.findById(buyerId).map(buyer -> {
        cartItem.setBuyer(buyer);
        return cartdao.save(cartItem);
    });
}
public ShoppingCart addingCartItem(int bid, ShoppingCart cart) {
Buyer b= buyerdao.getOne(bid);
System.out.println(b);
cart.setBuyer(b);
return cartdao.save(cart);
	
}
public Optional<ShoppingCart> addCartItem(ShoppingCart cartItem,Integer buyerId) {

		return buyerdao.findById(buyerId).map((buyer) -> {
            cartItem.setBuyer(buyer);
            System.out.println("controller1111");
            return cartdao.save(cartItem);
        });
	}*/
public void deleteAllCartItems(int bid) {
	Optional<Buyer> b=buyerdao.findById(bid);
	System.out.println(b);
	
}
public void deleteCartItembid(int id) {
	// TODO Auto-generated method stub
	 cartdao.deleteCartItembid(id);
	
}

public List<ShoppingCart> getCartItemsById(int bid) {
	
	return cartdao.getCartItemsById(bid);
}

public Optional<ShoppingCart> addCartItem(ShoppingCart cart, int bid) {
	return buyerdao.findById(bid).map((buyer) -> {
        cart.setBuyer(buyer);
        System.out.println("controller1111");
        return cartdao.save(cart);
    });
	
	
}




	
}




