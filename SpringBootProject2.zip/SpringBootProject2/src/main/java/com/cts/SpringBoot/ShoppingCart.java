package com.cts.SpringBoot;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="shopping_cart")
public class ShoppingCart implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartId;
	private int numberofitems;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyer;
	@ManyToOne
	@JoinColumn(name="item_key")
	private Items items;
	public Items getItems() {
		return items;
	}
	public void setItems(Items items) {
		this.items = items;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	
	public int getNumberofitems() {
		return numberofitems;
	}
	public void setNumberofitems(int numberofitems) {
		this.numberofitems = numberofitems;
	}
	
	public ShoppingCart(int cartId, int numberofitems, Buyer buyer, Items items) {
		super();
		this.cartId = cartId;
		this.numberofitems = numberofitems;
		this.buyer = buyer;
		this.items = items;
	}
	public ShoppingCart() {
		super();
	}


}
