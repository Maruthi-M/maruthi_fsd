package com.cts.SpringBoot.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;
import com.cts.SpringBoot.service.Projectservice;
import com.cts.SpringBoot.service.ShoppingCartService;

@RestController
public class ShoppingCartController

{
	@Autowired
	private ShoppingCartService service;

	// deleting an item cart-w
	@RequestMapping("deleteCartItem/{id}")
	public void deleteCartItem(@PathVariable("id") int id) {
		service.deleteCartItem(id);

	}
	//empty cart items by buyer id-w
	@RequestMapping("deleteCartItemByBuyer/{bid}")
	public void deleteCartItembid(@PathVariable("bid") int id) {
		service.deleteCartItembid(id);

	}
	//get cart items by id
	@RequestMapping("getCartItemsById/{bid}")
	public List<ShoppingCart> getCartItemsById(@PathVariable("bid") int bid)
	{
		return service.getCartItemsById(bid);
		
	}
	
	// add cart item
	/*
	 * @RequestMapping(value = "addcartitem/{buyerId}", method = RequestMethod.POST,
	 * produces = "application/json") public ShoppingCart
	 * addCartItems(@PathVariable(value = "buyerId") int buyerId,@RequestBody
	 * ShoppingCart cart) { Optional<ShoppingCart> savedItem
	 * =service.addCartItem(cart, buyerId); return savedItem.get(); }
	 */

	/*
	 * public List<ShoppingCart> getallCartItems(Integer buyerId){
	 * List<ShoppingCart> items = service.findAllBybuyer(buyerId); return items; }
	 */
	/// adding cart item
	/*
	 * @RequestMapping(value="addingCartItem") public ShoppingCart
	 * addingCartItem(@PathVariable("bid") int bid,@PathVariable("id") int id) {
	 * Optional<ShoppingCart> savedintocart=service.addingCartItem(bid,id); return
	 * savedintocart.get(); }
	
	// adding cart item
	@RequestMapping(value = "addingCartItem/{buyerid}", method = RequestMethod.POST, produces = "application/json")
	public ShoppingCart addingCartItems(@PathVariable("bid") int bid, @RequestBody ShoppingCart cart) {
		System.out.println("controller");
		return service.addingCartItem(bid, cart);
	}*/

	@RequestMapping(value = "addcartitem/{buyerId}", method = RequestMethod.POST, produces = "application/json")
	public ShoppingCart addCartItem(@PathVariable(value = "buyerId") int buyerId, @RequestBody ShoppingCart cartItem) {
		Optional<ShoppingCart> savedItem = service.addCartItem(cartItem,buyerId);
		System.out.println("controller");
		return savedItem.get();
	} 
	///adding
	/*@RequestMapping(value="addCartItem/{bid}")
	public ShoppingCart addCartItem(@PathVariable("bid") int bid,@RequestBody ShoppingCart cart)
	{
		return service.addCartItem(cart,bid);
	}*/

	// delete all cart items
	@RequestMapping(value = "deleteAllCartItems/{buyerid}")
	public String deleteAllCartItems(@PathVariable("buyerid") int bid) {
		service.deleteAllCartItems(bid);
		return "all cart items deleted";
	}

}
