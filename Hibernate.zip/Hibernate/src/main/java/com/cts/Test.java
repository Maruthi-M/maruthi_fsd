package com.cts;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


public class Test {
	public static void main(String args[])
	{
	Configuration configuration = new Configuration().configure();
    StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
    SessionFactory factory = configuration.buildSessionFactory(builder.build());
    Session session = factory.openSession();
    /*Employee emp=new Employee(1003,"ramu","admin");//transient state
//Employee e1=new Employee();//transient state
//session.save(emp);//no data inserted in db
session.beginTransaction();
Serializable obj=session.save(emp);
session.getTransaction().commit();
System.out.println(obj);
session.close();*/
   /* //inserting single data in db
    Employee emp1=new Employee(1000,"amar",",manager");//transient state so not inserted in db
    session.beginTransaction();
    session.save(emp1);
    session.getTransaction().commit();
    session.close();
   */
    /*//inserting multiple data in db
     Employee emp2=new Employee(2000,"bindhu","admin");
    Employee emp3=new Employee(2001,"chandhu","employee");
    session.beginTransaction();
    session.save(emp2);
    session.save(emp3);
    session.getTransaction().commit();
    session.close();*/
    /*//not updated in db ..because we use set() after commit so it wont reflect on db
     Employee emp4=new Employee(2002,"dinesh","admin");
    session.beginTransaction();
    session.save(emp4);
    session.getTransaction().commit();
   emp4.setEmployeeDesig("M1");
   session.close();*/
    /*saveorupdate():Hibernate: select employee_.employeeId, employee_.employeeDesig as employee2_0_, employee_.employeeName as employee3_0_ from Employee employee_ where employee_.employeeId=?
Hibernate: insert into Employee (employeeDesig, employeeName, employeeId) values (?, ?, ?)
     * Employee emp5=new Employee(2003,"eshwar","manager");
     
    session.beginTransaction();
    session.saveOrUpdate(emp5);
    session.getTransaction().commit();*/
    /*//get()Hibernate: select employee0_.employeeId as employee1_0_0_, employee0_.employeeDesig as employee2_0_0_, employee0_.employeeName as employee3_0_0_ from Employee employee0_ where employee0_.employeeId=?
//Hibernate: update Employee set employeeDesig=?, employeeName=? where employeeId=?
   Employee emp6=(Employee)session.get(Employee.class, 1000);
   session.beginTransaction();
   emp6.setEmployeeDesig("updated as M1");
   session.getTransaction().commit();  */ 
    /*//d
Employee emp7=(Employee)session.load(Employee.class,2000);
session.beginTransaction();
emp7.setEmployeeName("binitha");
session.getTransaction();*/
/*Employee e1=(Employee) session.get(Employee.class, 200);
System.out.println(e1.getEmployeeId());
System.out.println(e1.getEmployeeName());*/
   /* Employee e2=new Employee(10,"ganesh","emp1");
    session.beginTransaction();
    session.saveOrUpdate(e2);
    session.getTransaction().commit();*/
    Employee e3=new Employee(901,"manu","emp09");//transient state
    session.beginTransaction();
    session.save(e3);//managed state
    session.evict(e3);//deatched state
    e3.setEmployeeName("manoj");
    session.update(e3);//moving deatch state to persistent state
    session.getTransaction().commit();

    
    
 



}
}
