package com.cts;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Employee implements Serializable {
	@Id
	private int employeeId;
	private String employeeName;
	private String employeeDesig;
	
	public Employee() {
	
	}
public Employee(int employeeId, String employeeName, String employeeDesig) {

		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeDesig = employeeDesig;
	}





	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeDesig() {
		return employeeDesig;
	}
	public void setEmployeeDesig(String employeeDesig) {
		this.employeeDesig = employeeDesig;
	}

}
