export class AptModel
{
   // id:number
    firstname:string;
    lastname:string;
    password:number;
    email:string;
    phonenumber:number;
    street:string;
    city:string;
    state:string;
    zip:number;
    country:string;
    trainerpreference:string;
    physio:boolean;
    slot:string;

    packageprice:number;
    Quote:number;
    //optradio:String;
    text2:String;
}