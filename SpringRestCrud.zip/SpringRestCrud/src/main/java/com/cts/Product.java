package com.cts;

public class Product {
	private int productid;
	private String Productname;
	private int productquantity;
	private float productprice;
	public Product()
	{
		
	}
	public Product(int productid, String productname, int productquantity, float productprice) {
		
		this.productid = productid;
		Productname = productname;
		this.productquantity = productquantity;
		this.productprice = productprice;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return Productname;
	}
	public void setProductname(String productname) {
		Productname = productname;
	}
	public int getProductquantity() {
		return productquantity;
	}
	public void setProductquantity(int productquantity) {
		this.productquantity = productquantity;
	}
	public float getProductprice() {
		return productprice;
	}
	public void setProductprice(float productprice) {
		this.productprice = productprice;
	}
	

}
