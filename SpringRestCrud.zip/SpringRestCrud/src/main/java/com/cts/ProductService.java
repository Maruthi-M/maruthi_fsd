package com.cts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Product;
@Service
public class ProductService {
	@Autowired
	ProductDao pdao;
	public Product getbyid(int productid)
	{
		return pdao.getById(productid);
	}
public int deleteProduct(int prodId) {
		
		return pdao.deleteProduct(prodId);
	}
public int updateProduct(Product product, int prodId) {
	
	return pdao.updateProduct(product,prodId);
}
public int addProduct(Product product) {
	
	return pdao.addProduct(product);
}
}
