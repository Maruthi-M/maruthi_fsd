package com.cts;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.Product;
@Repository
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	public Product getById(int productid) {
		jdbc = new JdbcTemplate(ds);
		String sql = "SELECT * FROM product WHERE productid=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {productid},new RowMapper<Product>() {
			
			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product product = new Product();

				product.setProductid(rs.getInt(1));
				product.setProductname(rs.getString(2));
				product.setProductquantity(rs.getInt(3));
				product.setProductprice(rs.getFloat(4));

				return product;
			}

		});
	return product;
	}
	public int deleteProduct(int productid) {
		jdbc = new JdbcTemplate(ds);
		int count = jdbc.update("DELETE FROM product WHERE productid=?", new Object[] {productid});
		return count;
	}
	public int updateProduct(Product product, int prodId) {
		jdbc = new JdbcTemplate(ds);
		String sql = "UPDATE product SET productname=?, productquantity=?, productprice=? WHERE productid =?";
		int count = jdbc.update(sql,new Object[] 
				{product.getProductname(),product.getProductquantity(),product.getProductprice(),product.getProductid()});
		return count;
	}
	public int addProduct(Product product){
		jdbc = new JdbcTemplate(ds);
		int storedStatus = jdbc.update("INSERT INTO product VALUES(?,?,?,?)", new Object[] {product.getProductid(),product.getProductname(),product.getProductquantity(),product.getProductprice()});
		System.out.println(storedStatus);
		return product.getProductid();
	}
	
	
}
