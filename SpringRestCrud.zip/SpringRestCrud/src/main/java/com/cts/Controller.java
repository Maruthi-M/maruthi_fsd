package com.cts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cts.Product;

@RestController
public class Controller {
	@Autowired
	ProductService proservice;
	@RequestMapping(value="/getbyid/{productid}",method=RequestMethod.GET)
	public ResponseEntity<Product> getbyid(@PathVariable("productid") int productid) {
		Product product = proservice.getbyid(productid);
		if(product == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
	@RequestMapping(value="/deleteproductbyid/{productid}",method = RequestMethod.DELETE)
	public int deleteProduct(@PathVariable("productid") int productid){
		return proservice.deleteProduct(productid);

	}
	@RequestMapping(value="/updateproductbyid/{prodId}", method = RequestMethod.PUT)
	public int updateProduct(@PathVariable("prodId") int prodId, @RequestBody Product product){
		return proservice.updateProduct(product,prodId);
		
	}
	@RequestMapping(value="/addproduct",method=RequestMethod.POST,produces = "application/json")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		HttpHeaders headers = new HttpHeaders();
		if(product == null) {
			return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
		}
		proservice.addProduct(product);		
		headers.add("Product Object Created -",String.valueOf(product.getProductid()));
		return new ResponseEntity<Product>(product,headers,HttpStatus.CREATED);
	}


}
